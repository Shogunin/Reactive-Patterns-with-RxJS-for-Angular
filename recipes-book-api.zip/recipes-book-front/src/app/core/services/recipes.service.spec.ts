import {RecipesService} from "./recipes.service";
import {HttpClientTestingModule, HttpTestingController} from "@angular/common/http/testing";
import {TestBed} from "@angular/core/testing";

describe('RecipesService', () => {
  let service: RecipesService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [RecipesService]
    });
    httpTestingController = TestBed.inject(HttpTestingController);
    service = TestBed.inject(RecipesService);
  });

  it('should save recipe from API', () => {
    const recipeToSave = {};
    const subscription = service.saveRecipe(recipeToSave).subscribe(recipe => {
      expect(recipe).toEqual(recipe, 'shoould check mock data')
    });

    const req = httpTestingController.expectOne('/api/recipes/save');
    req.flush(recipeToSave);
    subscription.unsubscribe();
  });

  afterEach(() => {
    httpTestingController.verify();
  })
})
