import {Injectable} from '@angular/core';
import {WebSocketSubject} from "rxjs/internal/observable/dom/WebSocketSubject";
import {Message} from "../model/message.model";
import {environment} from "../../../environments/environment";
import {webSocket} from "rxjs/webSocket";
import {catchError, delayWhen, retryWhen, tap} from "rxjs/operators";
import {BehaviorSubject, EMPTY, Observable, switchAll, timer} from "rxjs";

const WS_ENDPOINT = environment.wsEndpoint;
const RECONNECT_INTERVAL = environment.reconnectInterval;

@Injectable({
  providedIn: 'root'
})
export class RealTimeService {

  private socket$: WebSocketSubject<Message> | undefined;
  private messagesSubject$ = new BehaviorSubject<Observable<Message>>(EMPTY);
  public messages$ = this.messagesSubject$.pipe(switchAll(), catchError(e => {
    throw e
  }))

  constructor() {
    setTimeout(() => {
      this.close();
    }, 7000)
  }

  getNewWebSocket(): WebSocketSubject<Message> {
    return webSocket({
      url: WS_ENDPOINT,
      closeObserver: {
        next: () => {
          console.log('[DataService] Connection closed');
          this.socket$ = undefined;
          this.connect({reconnect: true});
        }
      }
    });
  }

  sendMessage(msg: Message) {
    this.socket$?.next(msg);
  }

  close() {
    this.socket$?.complete();
  }

  connect(cfg: { reconnect: boolean } = {reconnect: false}): void {
    if (!this.socket$ || this.socket$.closed) {
      this.socket$ = this.getNewWebSocket();
      const message = this.socket$.pipe(
        cfg.reconnect ? this.reconnect : webSocketSubject => webSocketSubject,
        tap(res => {
          console.log(res)
        }), catchError(_ => EMPTY)
      )
      this.messagesSubject$.next(message);
    }
  }

  private reconnect(observable: Observable<Message>): Observable<Message> {
    return observable.pipe(retryWhen(errors => errors.pipe(
      tap(value => console.log('[Data service] Try to reconnect', value)), delayWhen(_ => timer(RECONNECT_INTERVAL))
    )))
  }

}
