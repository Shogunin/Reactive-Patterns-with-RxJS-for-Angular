import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject, delay, Observable, shareReplay, switchMap, take, timer} from 'rxjs';
import {Recipe} from '../model/recipe.model';
import {retryWhen, tap} from 'rxjs/operators'
import {environment} from 'src/environments/environment';

const BASE_PATH = environment.basePath

@Injectable({
  providedIn: 'root'
})
export class RecipesService {

  interval$ = timer(0, 4000);
  recipes$ = this.getRecipes();
  private filterRecipeSubject = new BehaviorSubject<Recipe>({title: ''});
  filterRecipesAction$ = this.filterRecipeSubject.asObservable();

  constructor(private http: HttpClient) {
  }

  getRecipes(): Observable<Recipe[]> {
    return this.interval$.pipe(switchMap(() => {
        return this.http.get<Recipe[]>(`${BASE_PATH}/recipes`).pipe(
          tap(console.log),
          retryWhen(errors => {
            return errors.pipe(
              delay(3000),
              take(3),
              tap(() => console.log('Retrying http')))
          }),
          take(3),
          shareReplay(1)
        );
      }),
      shareReplay()
    )
  }

  updateFilter(criteria: Recipe) {
    this.filterRecipeSubject.next(criteria);
  }

  saveRecipe(formValue: Recipe): Observable<Recipe> {
    return this.http.post<Recipe>(`${BASE_PATH}/recipes/save`, formValue);
  }
}
