export const TAGS = [{name: 'Dinner', key: 'Dinner'},
  {name: 'Healthy', key: 'Healthy'}, {name: 'Salty', key: 'Salty'}, {name: 'Sweet', key: 'Sweet'},
  {name: 'Italian', key: 'Italian'},
  {name: 'Lunch', key: 'Lunch'},
  {name: 'Breakfast', key: 'Breakfast'},

];
