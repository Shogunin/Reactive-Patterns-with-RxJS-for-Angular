export interface Message {
  key: string,
  message: string
}
