export interface UploadStatus {
  status: string
}
