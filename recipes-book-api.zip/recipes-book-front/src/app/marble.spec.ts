import {Observable, of, switchMap, take, timer} from "rxjs";
import {TestScheduler} from "rxjs/internal/testing/TestScheduler";

export class SampleService {
  getValues(): Observable<string> {
    return of('Hello', 'Packt', 'Readers');
  }

  getTimedValues(): Observable<any> {
    return timer(0, 5000).pipe(
      take(3),
      switchMap(() => of(1, 2, 3))
    )
  }
}

describe('Service: SampleService', () => {
  let scheduler: TestScheduler;
  let service: SampleService;
  beforeEach(() => {
    service = new SampleService();
    scheduler = new TestScheduler((actual, expected) => {
      expect(actual).toEqual(expected);
    })
  });

  it('should return values in right order', () => {
    scheduler.run(({expectObservable}) => {
      const expectedMarble = '(abc|)';
      const expectedValues = {a: 'Hello', b: 'Packt', c: 'Readers'}

      expectObservable(service.getValues()).toBe(expectedMarble, expectedValues);
    })
  });

  it('should return marbles in right time', () => {
    scheduler.run(({expectObservable}) => {
      const expectMarble = '(abc) 4995ms (abc) 4995ms (abc|)';
      const expectedValues = {a: 1, b: 2, c: 3};

      expectObservable(service.getTimedValues()).toBe(expectMarble, expectedValues);
    })
  })
})
