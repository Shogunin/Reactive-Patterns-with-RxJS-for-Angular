import {Component} from '@angular/core';
import {RealTimeService} from "./core/services/real-time.service";
import {catchError, map, tap} from "rxjs/operators";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  liveData$ = this.service.messages$.pipe(
    map(rows => rows.message),
    catchError(error => {
      throw error
    }),
    tap({
      error: error => console.log(`[Live component Error] ${error}`),
      complete: () => console.log('[Live component] Connection closed')
    })
  )

  constructor(private service: RealTimeService) {
    this.service.connect();
  }
}
