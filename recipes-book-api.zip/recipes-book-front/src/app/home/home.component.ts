import {Component} from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styles: ['app-recipes-list {flex: 1}']
})
export class HomeComponent {

  constructor() {
  }

}
