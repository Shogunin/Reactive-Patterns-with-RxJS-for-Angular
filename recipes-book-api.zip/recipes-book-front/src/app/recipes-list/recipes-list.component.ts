import {ChangeDetectionStrategy, Component, OnInit} from '@angular/core';
import {RecipesService} from '../core/services/recipes.service';
import {combineLatest} from "rxjs";
import {map} from "rxjs/operators";
import {Recipe} from "../core/model/recipe.model";
import {SharedDataService} from "../core/services/shared-data.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-recipes-list',
  templateUrl: './recipes-list.component.html',
  styleUrls: ['./recipes-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RecipesListComponent implements OnInit {

  recipes$ = this.service.recipes$;
  filteredRecipe$ = combineLatest([this.recipes$, this.service.filterRecipesAction$]).pipe(
    map(([recipes, filter]: [Recipe[], Recipe]) => {
      return recipes.filter(recipe => recipe.title?.toLowerCase().indexOf(filter.title!.toLowerCase() ?? '') != -1);
    })
  );

  constructor(private service: RecipesService,
              private sharedDataService: SharedDataService,
              private router: Router
  ) {
  }

  ngOnInit(): void {
    setTimeout(() => {
    })
  }

  editRecipe(recipe: Recipe) {
    console.log(`/recipes/details/${recipe.id}`)
    this.sharedDataService.updateSelectedRecipe(recipe);
    this.router.navigate([`/recipes/details/${recipe.id}`])
  }
}
