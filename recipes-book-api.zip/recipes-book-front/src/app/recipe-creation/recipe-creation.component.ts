import {Component, OnInit} from '@angular/core';
import {FormBuilder} from '@angular/forms';
import {RecipesService} from '../core/services/recipes.service';
import * as recipeTags from '../core/model/tags';
import {catchError, tap} from 'rxjs/operators';
import {BehaviorSubject, debounceTime, finalize, forkJoin, of, switchMap} from 'rxjs';
import {Recipe} from "../core/model/recipe.model";
import {HttpErrorResponse} from "@angular/common/http";
import {UploadRecipePreviewService} from "../core/services/upload-recipe-service-preview.service";

@Component({
  selector: 'app-recipe-creation',
  templateUrl: './recipe-creation.component.html',
})
export class RecipeCreationComponent implements OnInit {

  uploadedFileSubject$ = new BehaviorSubject<File[]>([]);
  uploadProgress: number = 0;
  counter: number = 0;

  recipeForm = this.formBuilder.group({
    id: Math.floor(1000 + Math.random() * 9000),
    title: [''],
    ingredients: [''],
    tags: [''],
    imageUrl: [''],
    cookingTime: [''],
    yield: [''],
    prepTime: [''],
    steps: ['']
  });
  tags = recipeTags.TAGS;

  valueChanges$ = this.recipeForm.valueChanges.pipe(
    debounceTime(0),
    switchMap(formValue => {
      const disposableStream$ = this.service.saveRecipe(formValue);
      return disposableStream$.pipe(
        catchError((err) => {
          return of(err)
        })
      )
    }),
    tap(result => {
      if (result instanceof HttpErrorResponse) {
        this.saveFailed();
        return;
      }
      this.saveSuccess(result)
    })
  );

  uploadRecipeImages$ = this.uploadedFileSubject$.pipe(
    switchMap(uploadedFiles => {
      return forkJoin(uploadedFiles.map((file: File) => {
        return this.uploadRecipePreviewService.upload(this.recipeForm.value.id, file).pipe(
          catchError(errors => of(errors)),
          finalize(() => {
            console.log('finalize');
            this.calculateProgress(++this.counter, uploadedFiles.length)
          })
        );
      }))
    })
  )

  constructor(private formBuilder: FormBuilder, private service: RecipesService, private uploadRecipePreviewService: UploadRecipePreviewService) {
  }

  ngOnInit(): void {
  }

  saveSuccess(result: Recipe) {
    console.log('Saved successfully', result);
  }

  saveFailed() {
    console.log('Saved failed');
  }

  onUpload(files: File[]) {
    this.uploadedFileSubject$.next(files);
  }

  private calculateProgress(completedRequests: number, totalRequests: number) {
    this.uploadProgress = (completedRequests / totalRequests) / 100;
  }
}
