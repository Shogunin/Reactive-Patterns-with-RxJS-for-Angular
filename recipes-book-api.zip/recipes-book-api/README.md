# recipes-api

This is a mocked API for RecipesApp using json-server